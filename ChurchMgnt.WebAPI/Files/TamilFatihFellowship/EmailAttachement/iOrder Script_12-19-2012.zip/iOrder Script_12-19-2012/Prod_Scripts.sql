
USE ORDERPROCESSING
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'faafc7aa-b1df-4ffa-8078-8bec26cf24c6',null,0,null,null,'2012-12-19 10:7:35.254','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (45,CONVERT(varchar(12), @NewSeqVal),null,60000,1,'usp_insertorderlineitem')
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,10000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

 

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'ebb7fa3b-c644-433e-a118-45d97e8d077e',null,0,null,null,'2012-12-19 10:7:39.144','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (59,CONVERT(varchar(12), @NewSeqVal),null,100000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'8c47588e-f3cf-4c67-8759-5cfaa0ba243a',null,0,null,null,'2012-12-19 10:7:43.896','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,200000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'d50b7c7e-925b-4038-9a25-b52252c02963',null,0,null,null,'2012-12-19 10:7:43.985','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,80000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'d50b7c7e-925b-4038-9a25-b52252c02963',null,0,null,null,'2012-12-19 10:7:44.1','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,26000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'01bbc888-944f-436a-a06e-0647ff62c395',null,0,null,null,'2012-12-19 10:7:44.488','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,60000,1,'usp_insertorderlineitem')
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (3,CONVERT(varchar(12), @NewSeqVal),null,1000,1,'usp_insertorderlineitem')
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (4,CONVERT(varchar(12), @NewSeqVal),null,1000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'30576445-e5a0-4da5-b1fe-f6cd72bf07c9',null,0,null,null,'2012-12-19 10:7:44.504','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,100000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################


DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'954c710a-f333-4ab0-932a-8c9bc0eb8988',null,0,null,null,'2012-12-19 10:7:44.658','2012-12-24','2012-12-21','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,50000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO


--#########################################################################################################################################################################


DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'b523767e-32c7-4dd6-a4e7-aedc5288b641',null,0,null,null,'2012-12-19 10:7:44.672','2012-12-24','2012-12-21','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,58000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'a73e0580-ba32-4dbd-b53d-acfb6760820c',null,0,null,null,'2012-12-19 10:7:44.687','2012-12-24','2012-12-21','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,58000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'c49fd70d-b072-4ff9-870e-f3f76efb2e7a',null,0,null,null,'2012-12-19 10:7:45.270','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,120000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'7b31ed7c-b8fe-4e2e-8d15-688677d16b2f',null,0,null,null,'2012-12-19 10:7:45.324','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,120000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################

DECLARE @NewSeqVal int
EXEC @NewSeqVal = usp_GetNewSeqVal_tblOrder
INSERT INTO tblOrder (PK_CustomerOrderID, OneSysLocalOrderID, BankOrderID, FK_LocationID, Picked, Shipped, Prepared, Carrier, ReceiveDateTime, DeliveryDateTime, DispatchDateTime, UserID, OrderType, OrderSentToBranchDate, OrderStatus, Printed, OrderCreateMethod, PasswordID, ActiveFlag, LoginID, FK_FulfillmentStatusId, FK_ApprovalStatusId, PromoteDateTime)
VALUES (CONVERT(varchar(12), @NewSeqVal),null,null,'b88340b9-22d1-498b-9f93-c6b9c11ff9a0',null,0,null,null,'2012-12-19 10:7:45.341','2012-12-24','2012-12-20','standingorders','R',null,0,null,'S','db0d2bd3-4c1e-4860-b50b-b48b98cafb3e',1,'usp_insertorder',1,1,null)
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (3,CONVERT(varchar(12), @NewSeqVal),null,1000,1,'usp_insertorderlineitem')
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (5,CONVERT(varchar(12), @NewSeqVal),null,60000,1,'usp_insertorderlineitem')
INSERT INTO tblOrderLineItem (FK_OrderItemID, FK_CustomerOrderID, Quantity, LineItemValue, ActiveFlag, LoginID)
VALUES (4,CONVERT(varchar(12), @NewSeqVal),null,1000,1,'usp_insertorderlineitem')

UPDATE tblOrder SET OrderTotal = ( SELECT SUM(LineItemValue) FROM tblOrderLineItem WHERE FK_CustomerOrderID = @NewSeqVal ) WHERE PK_CustomerOrderID = @NewSeqVal
GO

--#########################################################################################################################################################################